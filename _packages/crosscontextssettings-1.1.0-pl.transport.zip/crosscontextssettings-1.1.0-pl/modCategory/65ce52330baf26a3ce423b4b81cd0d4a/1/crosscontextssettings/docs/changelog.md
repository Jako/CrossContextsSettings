CrossContextsSettings 1.1.0-pl (March 04, 2021)
-------------------------------------------------------
- Remove modAction usage
- [#19] Don't save the context_key and the area in updatefromgrid processor
- [#22] Fix ONLY_FULL_GROUP_BY issue
- Restrict the displayed contexts by system setting
- Clear cache after creating/editing a context setting by system setting
- [#23] Remove limit from Contexts
- [#18] Fix overflow scroll issue
- [#15] List the contexts of all namespaces by default

CrossContextsSettings 1.0.5-pl (January 22, 2016)
-------------------------------------------------------
- added namespace and area to the grid
- [#13] Pagination not working, 1.0.3

CrossContextsSettings 1.0.4-pl (January 18, 2016)
-------------------------------------------------------
- [#14] Fixed grid for context's name beyond [w]eb

CrossContextsSettings 1.0.3-pl (August 5, 2015)
-------------------------------------------------------
- [#12] lost contexts when parsing the panels

CrossContextsSettings 1.0.2-pl (July 28, 2015)
-------------------------------------------------------
- [#9] added "Clear Cache" tab
- [#8] fixed bug on 0 as value on "Create"
- [#10] set correct input type for setting value

CrossContextsSettings 1.0.1-pl (July 26, 2015)
-------------------------------------------------------
- [#8] fixed bug on 0 as value
- [#8] ignored same value

CrossContextsSettings 1.0.0-pl (July 25, 2015)
-------------------------------------------------------
- added delete setting
- [#2] Wanted: new context setting button

CrossContextsSettings 1.0.0-beta3 (July 03, 2015)
-------------------------------------------------------
- fixing pagination issue in MODX Revolution 2.3
- reduced pagesize to 10 and adapted grid height to show the whole grid
  (autoHeight is not possible because of lockinggridview limitations)
- fixing area filter (processor does not exist)
- fixing #3 Edited triangle does not go away
- changed UX to make the CMP look the same as other extras

CrossContextsSettings 1.0.0-beta2 (September 30, 2014)
-------------------------------------------------------
- prevent saving/remove setting when value is empty

CrossContextsSettings 1.0.0-beta1 (September 25, 2014)
-------------------------------------------------------
- initial release