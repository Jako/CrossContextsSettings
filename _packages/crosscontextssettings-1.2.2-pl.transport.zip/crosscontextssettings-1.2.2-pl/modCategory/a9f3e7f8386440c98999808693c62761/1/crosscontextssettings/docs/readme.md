# CrossContextsSettings

Edit the settings of different contexts in one place.

- Author: goldsky <goldsky@virtudraft.com>, https://twitter.com/_goldsky
- Current Maintainer: Thomas Jakobi <office@treehillstudio.com>
- License: GNU GPLv3

## Features

CrossContextsSettings is an custom manager page, where you could edit the
settings of different contexts in one place.

## Installation

MODX Package Management

## GitHub Repository

https://github.com/Jako/CrossContextsSettings
